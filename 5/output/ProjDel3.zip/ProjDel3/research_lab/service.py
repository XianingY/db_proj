"""Atomic business operations, using the exact Deliverable 2 schema."""
from contextlib import contextmanager

import psycopg
from psycopg import sql


CONSTRAINT_MESSAGES = {
    'uq_student_number': '学号已存在，不能重复',
    'fk_project_leader': '项目负责人必须是已存在的教师（faculty）',
    'fk_participation_member': '参与成员不存在',
    'fk_participation_project': '参与的项目不存在',
    'fk_grant_project': '资助所属项目不存在',
    'fk_device_equipment': '装置所属设备不存在',
    'fk_usage_member': '使用设备的成员不存在',
    'fk_usage_device': '指定的设备或装置编号不存在',
    'fk_authorship_member': '作者成员不存在',
    'fk_authorship_publication': '成果编号不存在',
    'fk_mentorship_mentee': '被指导者成员不存在',
    'fk_mentorship_mentor': '指导者成员不存在',
    'ck_member_type': '成员类型只能为 faculty、student 或 collaborator',
    'ck_project_status': '项目状态只能为 active、completed 或 paused',
    'ck_project_dates': '项目结束日期不能早于开始日期',
    'ck_completed_project': '项目状态为 completed 时必须填写结束日期',
    'ck_project_duration': '项目计划天数必须大于 0',
    'ck_participation_hours': '每周工时必须在 0 到 168 之间且不能为 NaN',
    'ck_grant_budget': '资助预算不能小于 0 且不能为 NaN',
    'ck_grant_duration': '资助预计天数必须大于 0',
    'ck_device_status': '装置状态只能为 available、in_use 或 retired',
    'ck_usage_dates': '设备使用结束时刻不能早于开始时刻',
    'ck_publication_year': '发表年份必须在 1 到 9999 之间',
    'ck_publication_month': '发表月份必须在 1 到 12 之间',
    'ck_publication_day': '发表日期不是合法的公历日（含平闰年校验）',
    'ck_mentorship_self': '成员不能自我指导',
    'ck_mentorship_dates': '指导结束日期不能早于开始日期',
}


def format_db_error(error):
    """Map PostgreSQL DDL constraint errors to clear Chinese messages while keeping constraint metadata."""
    if not isinstance(error, psycopg.Error):
        return str(error)
    constraint = error.diag.constraint_name
    sqlstate = error.sqlstate or ''
    if constraint:
        if constraint in CONSTRAINT_MESSAGES:
            text = CONSTRAINT_MESSAGES[constraint]
        elif constraint.startswith('pk_'):
            text = '编号主键已存在，不能重复插入'
        elif constraint.startswith('fk_'):
            text = '关联记录不存在或仍被其他表引用'
        elif constraint.startswith('ck_'):
            text = '字段取值不满足约束条件（例如不能为空白或超出范围）'
        else:
            text = error.diag.message_primary or str(error)
        return f'{text}（约束 {constraint}，SQLSTATE {sqlstate}）'
    return error.diag.message_primary or str(error)


# Field type is used by the CLI for strict parsing. '?' means nullable.
TABLES = {
    'lab_member': ('成员', ('member_id',), {
        'member_id':'编号', 'full_name':'姓名', 'member_type':'类型|str|faculty / student / collaborator',
        'join_date':'加入日期|date'}),
    'faculty': ('教师资料', ('member_id',), {'member_id':'成员编号','department':'院系'}),
    'student': ('学生资料', ('member_id',), {'member_id':'成员编号','student_number':'学号',
        'academic_level':'学业阶段','major':'专业'}),
    'external_collaborator': ('合作者资料', ('member_id',), {'member_id':'成员编号',
        'affiliation':'机构','short_cv':'简短履历|str|一段文字即可'}),
    'research_project': ('项目', ('project_id',), {'project_id':'项目编号','title':'标题',
        'start_date':'开始日期|date','end_date':'结束日期|date?|留空表示尚未结束',
        'planned_duration_days':'计划天数|int|大于 0','status':'状态|str|active / completed / paused','leader_id':'负责人编号|str|必须是教师；新增时自动补参与记录'}),
    'project_participation': ('项目参与', ('member_id','project_id'), {'member_id':'成员编号',
        'project_id':'项目编号','project_role':'角色','weekly_hours':'每周工时|decimal|0-168 小时'}),
    'research_grant': ('资助', ('grant_id',), {'grant_id':'资助编号','funding_agency':'资助机构',
        'budget':'预算 USD|decimal|不小于 0，两位小数','start_date':'开始日期|date',
        'expected_duration_days':'预计天数|int|大于 0','reporting_requirements':'报告要求','project_id':'项目编号'}),
    'equipment': ('设备', ('equipment_id',), {'equipment_id':'设备编号','equipment_name':'名称',
        'equipment_type':'类型','manual_location':'手册位置|str|例如 manuals/xxx.pdf'}),
    'device': ('具体装置', ('equipment_id','device_number'), {'equipment_id':'设备编号',
        'device_number':'装置编号|str|设备内唯一，不同设备可重号','purchase_date':'购买日期|date',
        'status':'状态|str|available / in_use / retired'}),
    'equipment_usage': ('设备使用记录', ('usage_id',), {'usage_id':'使用编号','member_id':'成员编号',
        'equipment_id':'设备编号','device_number':'装置编号',
        'started_at':'开始时刻|datetime|YYYY-MM-DD HH:MM:SS 北京时间',
        'ended_at':'结束时刻|datetime?|留空表示仍在使用','purpose':'目的'}),
    'publication': ('学术成果', ('publication_id',), {'publication_id':'成果编号','title':'标题',
        'publication_year':'发表年|int','publication_month':'发表月|int',
        'publication_day':'发表日|int?|只知道年月时填 NULL','venue':'发表场所','doi':'DOI|str?|可空'}),
    'authorship': ('成果作者', ('member_id','publication_id'), {'member_id':'成员编号','publication_id':'成果编号'}),
    'mentorship': ('指导关系', ('mentee_id',), {'mentee_id':'被指导者编号','mentor_id':'指导者编号|str|学生不能指导教师，不能自我指导',
        'start_date':'开始日期|date','end_date':'结束日期|date?|留空表示尚未结束'}),
}
SUBCLASSES = {'faculty':'faculty', 'student':'student', 'collaborator':'external_collaborator'}


def table_counts(conn):
    """All 13 table counts in one round-trip; names come from the TABLES whitelist.

    Shared by the web metadata endpoint and the terminal demo so both report the
    same numbers with the same number of database round-trips.
    """
    query = sql.SQL(' UNION ALL ').join(
        sql.SQL('SELECT {}::text AS table_name, COUNT(*) AS n FROM {}').format(
            sql.Literal(name), sql.Identifier(name))
        for name in TABLES)
    return {row['table_name']: row['n']
            for row in conn.execute(query).fetchall()}


class LabService:
    def __init__(self, connection):
        self.conn = connection

    def metadata(self, table):
        if table not in TABLES:
            raise ValueError('未知的表名')
        return TABLES[table]

    def _key_clause(self, table, key):
        keys = self.metadata(table)[1]
        if len(key) != len(keys):
            raise ValueError('主键列数不匹配')
        return sql.SQL(' AND ').join(sql.SQL('{}=%s').format(sql.Identifier(k)) for k in keys)

    def list_rows(self, table, search=None, limit=None, offset=None):
        self.metadata(table)
        query = sql.SQL('SELECT * FROM {}').format(sql.Identifier(table))
        params = []
        # Wildcards are intentionally passed through: an empty keyword lists
        # all rows, and a literal '%' is an explicit match-everything query in
        # the terminal demo. Escaping here would change the documented search
        # behaviour, so the convention is kept and pinned by a test.
        if search:
            columns = self.metadata(table)[2]
            query += sql.SQL(' WHERE ') + sql.SQL(' OR ').join(
                sql.SQL('CAST({} AS TEXT) ILIKE %s').format(sql.Identifier(c)) for c in columns)
            params.extend('%'+search+'%' for _ in columns)
        query += sql.SQL(' ORDER BY ') + sql.SQL(',').join(
            sql.Identifier(k) for k in self.metadata(table)[1])
        if limit is not None:
            try:
                limit = int(limit)
            except (TypeError, ValueError):
                raise ValueError('limit 必须是整数') from None
            if not 1 <= limit <= 1000:
                raise ValueError('limit 必须在 1 到 1000 之间')
            query += sql.SQL(' LIMIT %s')
            params.append(limit)
        if offset is not None:
            try:
                offset = int(offset)
            except (TypeError, ValueError):
                raise ValueError('offset 必须是整数') from None
            if offset < 0:
                raise ValueError('offset 不能为负数')
            query += sql.SQL(' OFFSET %s')
            params.append(offset)
        return self.conn.execute(query, tuple(params)).fetchall()

    def get_record(self, table, key):
        return self.conn.execute(sql.SQL('SELECT * FROM {} WHERE {}').format(
            sql.Identifier(table), self._key_clause(table,key)),tuple(key)).fetchone()

    @contextmanager
    def atomic(self):
        with self.conn.transaction():
            self.conn.execute('SELECT pg_advisory_xact_lock(1717,3)')
            self.conn.execute('SET CONSTRAINTS ALL DEFERRED')
            yield
            self.conn.execute('SELECT lab_assert_integrity()')
            self.conn.execute('SET CONSTRAINTS ALL IMMEDIATE')
            # Restore deferred mode so COMMIT re-checks the deferred triggers.
            # Verified with real transactions: a violating row written after
            # IMMEDIATE is rejected at COMMIT in deferred mode, but at INSERT in
            # immediate mode. atomic() has no writes between IMMEDIATE and here,
            # so the automated tests cannot observe it (reverse-verified); keep this
            # defensive second check rather than changing the commit timing.
            self.conn.execute('SET CONSTRAINTS ALL DEFERRED')

    def _insert(self, table, data):
        allowed = self.metadata(table)[2]
        if not data or set(data) - set(allowed):
            raise ValueError('插入包含未知字段或没有字段')
        columns = list(data)
        query = sql.SQL('INSERT INTO {} ({}) VALUES ({})').format(
            sql.Identifier(table),sql.SQL(',').join(map(sql.Identifier,columns)),
            sql.SQL(',').join(sql.Placeholder() for _ in columns))
        self.conn.execute(query,tuple(data[c] for c in columns))

    def create_record(self, table, data):
        if table in ('lab_member','research_project','equipment','publication'):
            raise ValueError('此实体必须使用带必需关系的组合新增操作')
        with self.atomic():
            self._insert(table,data)

    def create_member(self, member, subtype, participations):
        table = SUBCLASSES.get(member.get('member_type'))
        if not table:
            raise ValueError('成员类型只能为 faculty、student、collaborator')
        with self.atomic():
            self._insert('lab_member',member)
            self._insert(table,{**subtype,'member_id':member['member_id']})
            for p in participations:
                self._insert('project_participation',{**p,'member_id':member['member_id']})

    def create_project(self, project, participants):
        with self.atomic():
            self._insert('research_project',project)
            participants = list(participants)
            if not any(p['member_id']==project['leader_id'] for p in participants):
                participants.insert(0,dict(member_id=project['leader_id'],project_role='负责人',weekly_hours=0))
            for p in participants:
                self._insert('project_participation',{**p,'project_id':project['project_id']})

    def create_equipment(self, equipment, devices):
        with self.atomic():
            self._insert('equipment',equipment)
            for d in devices:
                self._insert('device',{**d,'equipment_id':equipment['equipment_id']})

    def create_publication(self, publication, author_ids):
        with self.atomic():
            self._insert('publication',publication)
            for member in author_ids:
                self._insert('authorship',dict(member_id=member,publication_id=publication['publication_id']))

    def update_record(self, table, key, changes):
        name, keys, columns = self.metadata(table)
        if not changes:
            return
        if set(changes) - set(columns) or set(changes) & set(keys):
            raise ValueError('编号主键不可修改，或修改包含未知字段')
        if table == 'lab_member' and 'member_type' in changes:
            raise ValueError('成员类型固定；更新对应子类资料即可')
        with self.atomic():
            self._require_record(table,key)
            self.conn.execute(sql.SQL('UPDATE {} SET {} WHERE {}').format(
                sql.Identifier(table),sql.SQL(',').join(
                    sql.SQL('{}=%s').format(sql.Identifier(c)) for c in changes),
                self._key_clause(table,key)),tuple(changes.values())+tuple(key))

    def _require_record(self, table, key):
        record=self.get_record(table,key)
        if record is None:
            raise ValueError('未找到此记录')
        return record

    def delete_record(self, table, key):
        self.metadata(table)
        with self.atomic():
            self._require_record(table,key)
            identifier=key[0]
            if table == 'lab_member':
                if self.conn.execute('SELECT 1 FROM research_project WHERE leader_id=%s',(identifier,)).fetchone():
                    raise ValueError('成员仍是项目负责人，请先更换负责人并添加其参与记录')
                self.conn.execute('DELETE FROM mentorship WHERE mentor_id=%s OR mentee_id=%s',(identifier,identifier))
                for rel in ['equipment_usage','authorship','project_participation']:
                    self.conn.execute(sql.SQL('DELETE FROM {} WHERE member_id=%s').format(sql.Identifier(rel)),(identifier,))
                for rel in ['faculty','student','external_collaborator']:
                    self.conn.execute(sql.SQL('DELETE FROM {} WHERE member_id=%s').format(sql.Identifier(rel)),(identifier,))
            elif table == 'research_project':
                for rel in ['research_grant','project_participation']:
                    self.conn.execute(sql.SQL('DELETE FROM {} WHERE project_id=%s').format(sql.Identifier(rel)),(identifier,))
            elif table == 'equipment':
                self.conn.execute('DELETE FROM equipment_usage WHERE equipment_id=%s',(identifier,))
                self.conn.execute('DELETE FROM device WHERE equipment_id=%s',(identifier,))
            elif table == 'publication':
                self.conn.execute('DELETE FROM authorship WHERE publication_id=%s',(identifier,))
            self.conn.execute(sql.SQL('DELETE FROM {} WHERE {}').format(
                sql.Identifier(table),self._key_clause(table,key)),tuple(key))

    def member_detail(self, member_id):
        """Return full member profile: superclass, matching subclass, participations, and mentorships."""
        member = self.get_record('lab_member', (member_id,))
        if member is None:
            raise ValueError('未找到此成员')
        subtype_table = SUBCLASSES[member['member_type']]
        subtype = self.get_record(subtype_table, (member_id,))
        participations = self.conn.execute("""
            SELECT pp.project_id, p.title, p.status, pp.project_role, pp.weekly_hours
            FROM project_participation AS pp
            JOIN research_project AS p ON p.project_id = pp.project_id
            WHERE pp.member_id = %s
            ORDER BY pp.project_id
        """, (member_id,)).fetchall()
        mentor = self.conn.execute("""
            SELECT ms.mentor_id, m.full_name AS mentor_name, ms.start_date, ms.end_date
            FROM mentorship AS ms
            JOIN lab_member AS m ON m.member_id = ms.mentor_id
            WHERE ms.mentee_id = %s
        """, (member_id,)).fetchone()
        mentees = self.conn.execute("""
            SELECT ms.mentee_id, m.full_name AS mentee_name, ms.start_date, ms.end_date
            FROM mentorship AS ms
            JOIN lab_member AS m ON m.member_id = ms.mentee_id
            WHERE ms.mentor_id = %s
            ORDER BY ms.mentee_id
        """, (member_id,)).fetchall()
        return {
            'member': dict(member),
            'subtype_table': subtype_table,
            'subtype': dict(subtype) if subtype else {},
            'participations': [dict(row) for row in participations],
            'mentor': dict(mentor) if mentor else None,
            'mentees': [dict(row) for row in mentees],
        }

    def reassign_project_leader(self, project_id, new_leader_id, weekly_hours=0):
        """Atomically reassign a project's leader, adding faculty participation if absent."""
        with self.atomic():
            self._require_record('research_project', (project_id,))
            if self.get_record('faculty', (new_leader_id,)) is None:
                raise ValueError('新负责人必须是已存在的教师（faculty）')
            if self.get_record('project_participation', (new_leader_id, project_id)) is None:
                self._insert('project_participation', {
                    'member_id': new_leader_id,
                    'project_id': project_id,
                    'project_role': '项目负责人',
                    'weekly_hours': weekly_hours,
                })
            self.conn.execute(
                'UPDATE research_project SET leader_id=%s WHERE project_id=%s',
                (new_leader_id, project_id))

    def update_member_with_subtype(self, member_id, member_changes, subtype_changes):
        """Atomically update lab_member and its matching subclass record in one transaction."""
        with self.atomic():
            member = self._require_record('lab_member', (member_id,))
            subtype_table = SUBCLASSES[member['member_type']]
            if member_changes:
                if set(member_changes) - set(TABLES['lab_member'][2]) or 'member_id' in member_changes:
                    raise ValueError('编号主键不可修改，或修改包含未知字段')
                if 'member_type' in member_changes:
                    raise ValueError('成员类型固定；更新对应子类资料即可')
                self.conn.execute(sql.SQL('UPDATE lab_member SET {} WHERE member_id=%s').format(
                    sql.SQL(',').join(sql.SQL('{}=%s').format(sql.Identifier(c)) for c in member_changes)),
                    tuple(member_changes.values()) + (member_id,))
            if subtype_changes:
                allowed = TABLES[subtype_table][2]
                if set(subtype_changes) - set(allowed) or 'member_id' in subtype_changes:
                    raise ValueError('子类资料修改包含未知字段或主键')
                self.conn.execute(sql.SQL('UPDATE {} SET {} WHERE member_id=%s').format(
                    sql.Identifier(subtype_table),
                    sql.SQL(',').join(sql.SQL('{}=%s').format(sql.Identifier(c)) for c in subtype_changes)),
                    tuple(subtype_changes.values()) + (member_id,))
